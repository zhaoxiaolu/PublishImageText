//
//  ViewController.h
//  ImageAndVideoAndRecord
//
//  Created by 李丹阳 on 2017/1/4.
//  Copyright © 2017年 李丹阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

