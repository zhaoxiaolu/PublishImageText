//
//  ZZPageControl.h
//  ZZFramework
//
//  Created by Yuan on 15/12/31.
//  Copyright © 2015年 zzl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZPageControl : UIView

@property (assign,nonatomic) NSInteger currentPage;
@property (strong,nonatomic) UILabel *pageControl;

@end
