//
//  ZZPhotoAlert.h
//  ZZPhotoKit
//
//  Created by 袁亮 on 16/8/28.
//  Copyright © 2016年 Ace. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZPhotoAlert : UIView

+(ZZPhotoAlert *) sharedAlert;

-(void) showPhotoAlert;

@end
